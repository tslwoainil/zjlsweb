<!DOCTYPE html>
<html>
<head>
<title>常用办公网址导航</title>
<!-- jQuery-->
<script src="js/jquery.min.js"></script>
<link rel="icon" href="images/favicon.ico" type="image/x-icon" />
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> 	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>

	<div class="header">
	<!---->
		<div class="header-left">
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li class="active" ><a href="index.php" >公共常用</a></li>
					<li><a href="work.html" class="black" > 售后部</a></li>	
					<li><a href="sales.html" class="black1"> 销售部</a></li>
					<li><a href="fin.html" class="black2" > 财务\金融保险</a></li>
					<li><a href="market.html" class="black3" > 市场\CRM</a></li>
					<li><a href="hr.html" class="black4" > HR\行政\IT</a></li>
					<li><a href="/movie/" class="black4" target="_self"> 召回服务措施</a></li>
                	<li><a href="/movie/glc/" class="black4" target="_self"> glc方向机服务措施</a></li>
				</ul>
			</div>
			<!--<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
				
			</ul> -->
			<br>
			<p class="footer-class">Copyright by  <a href="#" target="_blank">ZjlxStar Tian</a> </p>
		</div>
		<!---->
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.html"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="images/menu.png" alt=""> </span>
				<ul >
					<li class="active" ><a href="index.php" >公共常用</a></li>
					<li><a href="work.html" class="black" > 售后部</a></li>	
					<li><a href="sales.html" class="black1"> 销售部</a></li>
					<li><a href="fin.html" class="black2" > 财务金融保险</a></li>
					<li><a href="market.html" class="black3" > 市场/CRM</a></li>
					<li><a href="hr.html" class="black4" > HR/行政/IT</a></li>
					<li><a href="/movie/" class="black4" target="_self"> 召回服务措施</a></li>
					<li><a href="/movie/glc/" class="black4" target="_self"> glc方向机服务措施</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="content-grid">
			
				<a href="http://eip.ns.corp.lsh.com/Pages/Home.aspx" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi12.jpg" />
					 <div class="b-title">
                          <p>LSH-EIP</p>
						</div>
					 <div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行EIP</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
						
				</a>
			</div>
			
			
			<div class="content-grid">			
				<a href="http://dmsuat.denza.com" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/ts.png" />
					 <div class="b-title">
                          <p>腾势DOS系统</p>
						</div>
					 <div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>腾势数字化运营平台</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
						
				</a>
			</div>
			
			
			
			<div class="content-grid">			
				<a href="https://doctor-cn.i.daimler.com/" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-dgreen.jpg" />
					 <div class="b-title">
                          <p>DOCTOR</p>
						</div>
					 <div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>提交奔驰相关问题</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
						
				</a>
			</div>
			<div class="content-grid">
				<a href="https://myit-cn.i.daimler.com/ux/myitapp" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-e9ae6a.jpg" />
						<div class="b-title">
                          <p>MyIT</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>提交奔驰相关问题</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://china-portal.i.daimler.com/" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi5.jpg" />
						<div class="b-title">
                          <p>星播客</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>奔驰通知系统</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="http://10.150.0.64/lshworkflow/index.html?request_locale=zh_CN" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi8.jpg" />
						<div class="b-title">
                          <p>Workflow</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行审批系统</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://mail.lshauto.cn/owa" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-lsh1.jpg" />
						<div class="b-title">
                          <p>LSH邮箱</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行网页邮箱</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="http://10.150.2.99/psp/hcm92prd/EMPLOYEE/HRMS/?&cmd=login&languageCd=ZHS" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi6.jpg" />
						<div class="b-title">
                          <p>HRIS</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行人事系统</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://trainingmvp-cn.daimler.com/ssologin" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-bpink.jpg" />
						<div class="b-title">
                          <p>星平台OTL</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>奔驰培训系统</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://adss2.lsh.com/" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-gray.jpg" />
						<div class="b-title">
                          <p>ADSS</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行域账号密码找回</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="http://academy.lshauto.com.cn" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi3.jpg" />
						<div class="b-title">
                          <p>iLearning</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行爱学习</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="http://lshslm.ns.corp.lsh.com:50100/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?sap-client=001&sap-language=ZH" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-gray.jpg" />
						<div class="b-title">
                          <p>LSH ITSM</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>利星行IT运维平台</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid grid9">
				<a href="http://10.150.18.81:8001/sap/bc/gui/sap/its/webgui" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi3.jpg" />
						<div class="b-title">
                          <p>SAP ERP Web</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>SAP网页版</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			
			<div class="content-grid">
				<a href="https://aftersales.i.daimler.com" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-dgreen.jpg" />
						<div class="b-title">
                          <p>XentryPortal</p>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>Xentry Portal</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://sso.i.daimler.com/idp/startSSO.ping?PartnerSpId=https://daimlerchinacommunity.force.com" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi-org.jpg" />
						<div class="b-title">
                          <p>Salseforce /CRM-IT</p>
						 </div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>Salseforce /CRM-IT</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			
			<div class="content-grid">
				<a href="http://vsp.jd.com" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pijd.jpg" />
						<div class="b-title">
                          <p>京东慧采</p>
						 </div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>京东慧采平台</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="content-grid">
				<a href="https://dsd-cn.i.daimler.com/benz/index.php/admin/public/login.html" target="_blank" class="b-link-stripe b-animate-go  thickbox">
					<img  src="images/pi111.jpg" />
						<div class="b-title">
						  <p>OAB \ DOS</P>
						</div>
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span>售后预约系统</span>
								<p></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			<div class="clear"> </div>
			<!--<div class="arrow">
				<img  src="images/ic.png" />
				<ul class="social ">
					<li><span><i> </i>9930 1234 5679</span></li>
					<li><a href="mailto:info@example.com"><i class="mes"> </i>info@example.com</a></li>
					<li><span><i class="down"> </i>street address example</span></li>
				</ul>
			</div>  -->
		</div>
		<div class="clear"> </div>
		<p class="footer-class-in">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>
	</div>
	
	<script src="/js/main.min.js" type="208a5c7132654bad149fd52b-text/javascript"></script>
<script type="208a5c7132654bad149fd52b-text/javascript"> 
/* 鼠标特效 */
var a_idx = 0; 
jQuery(document).ready(function($) { 
    $("body").click(function(e) { 
        var a = new Array("富强 -中国加油", "民主 -中国加油", "文明 -中国加油", "和谐 -中国加油", "自由 -中国加油", "平等 -中国加油", "公正 -中国加油" ,"法治 -中国加油", "爱国 -中国加油", "敬业 -中国加油", "诚信 -中国加油", "友善 -中国加油"); 
        var $i = $("<span/>").text(a[a_idx]); 
        a_idx = (a_idx + 1) % a.length; 
        var x = e.pageX, 
        y = e.pageY; 
        $i.css({ 
            "z-index": 999999999999999999999999999999999999999999999999999999999999999999999, 
            "top": y - 20, 
            "left": x, 
            "position": "absolute", 
            "font-weight": "bold", 
            "color": "#ff6651" 
        }); 
        $("body").append($i); 
        $i.animate({ 
            "top": y - 180, 
            "opacity": 0 
        }, 
        1500, 
        function() { 
            $i.remove(); 
        }); 
    }); 
}); 
</script>
<script src="/js/rocket-loader.min.js" data-cf-settings="208a5c7132654bad149fd52b-|49" defer=""></script></body>
</body>
</html>