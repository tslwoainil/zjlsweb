<!DOCTYPE html>
<html>
<head>
<title>常用通讯录</title>
<!-- jQuery-->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="icon" href="images/favicon.ico" type="image/x-icon" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->
<base target="_self">
</head>
<body>
 	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li><a href="index.php" target="_self" >公共常用</a></li>
					<li><a href="work.html" class="black" target="_self"> 售后部</a></li>	
					<li><a href="sales.html" class="black1" target="_self"> 销售部</a></li>
					<li><a href="fin.html" class="black2" target="_self"> 财务\金融保险</a></li>
					<li><a href="market.html" class="black3" target="_self"> 市场\CRM</a></li>
					<li><a href="hr.html" class="black4" target="_self"> HR\行政\IT</a></li>
					<li class="active"><a href="txl.php" class="black4" target="_self"> 内部通讯录</a></li>
				</ul>
			</div>
			<p class="footer-class"> Copyright by  <a href="#" target="_blank">ZjlxStar Tian</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="images/menu.png" alt=""> </span>
				<ul >
					<li><a href="index.php"  target="_self">公共常用</a></li>
					<li><a href="work.html" class="black" target="_self"> 售后部</a></li>	
					<li><a href="sales.html" class="black1" target="_self"> 销售部</a></li>
					<li><a href="fin.html" class="black2" target="_self"> 财务\金融保险</a></li>
					<li><a href="market.html" class="black3" target="_self"> 市场\CRM</a></li>
					<li><a href="hr.html" class="black4" target="_self"> HR\行政\IT</a></li>
					<li class="active"><a href="txl.php" class="black4" target="_self"> 内部通讯录</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			    </script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				<form class="depform" method="post" name="form" action="txl.php">
				<div  class="wr-dep">
						<input type ="checkbox" name ="category[]"  checked="1"  value ="行政部"/>行政部
						<input type ="checkbox" name ="category[]"  value ="财务部"/>财务部
						<input type ="checkbox" name ="category[]" value ="HR"/>人力资源部
						<input type ="checkbox" name ="category[]" value ="信息管理部"/>信息管理部
						<input type ="checkbox" name ="category[]" value ="销售部"/>销售部
						<input type ="checkbox" name ="category[]" value ="售后部"/>售后部
						<input type ="checkbox" name ="category[]" value ="金融保险部"/>金融保险部
						<input type ="checkbox" name ="category[]" value ="市场部" />市场部
						<input type ="checkbox" name ="category[]" value ="客户关系部" />客户关系部
						<input type ="checkbox" name ="category[]"  value ="总经办" />总经办
					
				</div>
				<div style="padding:5px;">
					<input class="btn btn-defaulttype" type="submit" value="查询" />
				</div>
</form>
<div class="clear"> </div>
				
				
				<table class="tabcontact">
				<thead class="tabcontact-tou">
					<tr class="mui-tab-row">
					  <td>姓名</td><td>职位</td><td>部门</td><td>分机号</td><td>GEMS</td><td>手机</td><td>邮箱</td>
					</tr></thead>
					  
											
						

				  
				</table>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></p>

	</div>
</body>
</html>